"""
Dataset Builder for CodeComplexity AI.
Curates an educational dataset of representative C algorithms across 7 Big-O complexity classes:
- O(1)
- O(log n)
- O(n)
- O(n log n)
- O(n^2)
- O(2^n)
- O(n!)

Each example is carefully selected, categorized by algorithm family, and documented with genuine reasoning.
"""

import os
import pandas as pd
from typing import List, Dict, Any
from feature_extractor import extract_features_from_code, FEATURE_NAMES

# Educational dataset definitions:
PROGRAM_DATA = [
    # ==========================
    # 1. O(1) - Constant Time
    # ==========================
    {
        "name": "array_element_access",
        "family": "Array Access",
        "label": "O(1)",
        "reasoning": "Direct array index lookup performs in constant time with no loops or recursion.",
        "code": """
int getElement(int arr[], int index) {
    return arr[index];
}
"""
    },
    {
        "name": "swap_numbers",
        "family": "Arithmetic/Logic",
        "label": "O(1)",
        "reasoning": "Swapping two numbers using a temporary variable executes a fixed sequence of 3 assignments.",
        "code": """
void swap(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
}
"""
    },
    {
        "name": "is_even_check",
        "family": "Arithmetic/Logic",
        "label": "O(1)",
        "reasoning": "Checking parity using modulo/bitwise operator involves a single evaluation.",
        "code": """
int isEven(int n) {
    if (n % 2 == 0) {
        return 1;
    }
    return 0;
}
"""
    },
    {
        "name": "find_maximum_of_three",
        "family": "Conditional Logic",
        "label": "O(1)",
        "reasoning": "Branching decisions over three fixed scalar inputs take constant time.",
        "code": """
int maxOfThree(int a, int b, int c) {
    int max = a;
    if (b > max) {
        max = b;
    }
    if (c > max) {
        max = c;
    }
    return max;
}
"""
    },
    {
        "name": "hash_slot_lookup",
        "family": "Hash Lookup",
        "label": "O(1)",
        "reasoning": "Modular hash key calculation and single slot access execute in O(1).",
        "code": """
int getSlot(int table[], int key, int size) {
    int slot = key % size;
    return table[slot];
}
"""
    },
    {
        "name": "celsius_to_fahrenheit",
        "family": "Arithmetic/Formula",
        "label": "O(1)",
        "reasoning": "Closed-form mathematical formula evaluation has constant execution cost.",
        "code": """
int toFahrenheit(int celsius) {
    int fahr = (celsius * 9) / 5 + 32;
    return fahr;
}
"""
    },

    # ==========================
    # 2. O(log n) - Logarithmic
    # ==========================
    {
        "name": "iterative_binary_search",
        "family": "Binary Search",
        "label": "O(log n)",
        "reasoning": "Search space is halved at each iteration via mid = (l + r) / 2.",
        "code": """
int binarySearchIter(int arr[], int l, int r, int x) {
    while (l <= r) {
        int m = l + (r - l) / 2;
        if (arr[m] == x)
            return m;
        if (arr[m] < x)
            l = m + 1;
        else
            r = m - 1;
    }
    return -1;
}
"""
    },
    {
        "name": "recursive_binary_search",
        "family": "Binary Search",
        "label": "O(log n)",
        "reasoning": "Divides input range in half on each recursive call, making at most one recursive branch per step.",
        "code": """
int binarySearchRec(int arr[], int l, int r, int x) {
    if (r >= l) {
        int mid = l + (r - l) / 2;
        if (arr[mid] == x)
            return mid;
        if (arr[mid] > x)
            return binarySearchRec(arr, l, mid - 1, x);
        return binarySearchRec(arr, mid + 1, r, x);
    }
    return -1;
}
"""
    },
    {
        "name": "repeated_division_log",
        "family": "Number Theory",
        "label": "O(log n)",
        "reasoning": "Loop counter n is repeatedly divided by 2 until it reaches 0.",
        "code": """
int countHalvings(int n) {
    int count = 0;
    while (n > 1) {
        n = n / 2;
        count++;
    }
    return count;
}
"""
    },
    {
        "name": "binary_exponentiation",
        "family": "Number Theory",
        "label": "O(log n)",
        "reasoning": "Power exponentiation by squaring halves the power each step.",
        "code": """
int fastPow(int base, int exp) {
    int res = 1;
    while (exp > 0) {
        if (exp % 2 == 1)
            res = res * base;
        base = base * base;
        exp = exp / 2;
    }
    return res;
}
"""
    },
    {
        "name": "euclidean_gcd",
        "family": "Number Theory",
        "label": "O(log n)",
        "reasoning": "Euclidean algorithm reduces arguments exponentially through modulo division.",
        "code": """
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}
"""
    },
    {
        "name": "count_bits_shift",
        "family": "Bit Manipulation",
        "label": "O(log n)",
        "reasoning": "Shifting right by 1 each step (n >>= 1) processes binary bits logarithmically with respect to value n.",
        "code": """
int countBits(int n) {
    int bits = 0;
    while (n > 0) {
        bits += (n & 1);
        n >>= 1;
    }
    return bits;
}
"""
    },

    # ==========================
    # 3. O(n) - Linear Time
    # ==========================
    {
        "name": "linear_search",
        "family": "Linear Scanning",
        "label": "O(n)",
        "reasoning": "Iterates sequentially through n elements with a single loop.",
        "code": """
int linearSearch(int arr[], int n, int x) {
    for (int i = 0; i < n; i++) {
        if (arr[i] == x)
            return i;
    }
    return -1;
}
"""
    },
    {
        "name": "array_sum",
        "family": "Linear Scanning",
        "label": "O(n)",
        "reasoning": "Visits each element once in an array to compute sum.",
        "code": """
int arraySum(int arr[], int n) {
    int total = 0;
    for (int i = 0; i < n; i++) {
        total += arr[i];
    }
    return total;
}
"""
    },
    {
        "name": "find_maximum_element",
        "family": "Linear Scanning",
        "label": "O(n)",
        "reasoning": "Maintains current max over n sequential comparisons.",
        "code": """
int findMax(int arr[], int n) {
    int max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max)
            max = arr[i];
    }
    return max;
}
"""
    },
    {
        "name": "reverse_array",
        "family": "Two Pointer",
        "label": "O(n)",
        "reasoning": "Two pointers move inward from ends towards middle, taking n/2 iterations = O(n).",
        "code": """
void reverseArray(int arr[], int n) {
    int start = 0;
    int end = n - 1;
    while (start < end) {
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        start++;
        end--;
    }
}
"""
    },
    {
        "name": "recursive_linear_countdown",
        "family": "Linear Recursion",
        "label": "O(n)",
        "reasoning": "Linear recursion decrements n by 1 until 0 with a single recursive branch.",
        "code": """
int recursiveCountdown(int n) {
    if (n <= 0)
        return 0;
    return 1 + recursiveCountdown(n - 1);
}
"""
    },
    {
        "name": "count_occurrences",
        "family": "Linear Scanning",
        "label": "O(n)",
        "reasoning": "Single loop checking matches of a target element across array.",
        "code": """
int countMatches(int arr[], int n, int target) {
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i] == target)
            count++;
    }
    return count;
}
"""
    },

    # ==========================
    # 4. O(n log n) - Linearithmic
    # ==========================
    {
        "name": "merge_sort_helper",
        "family": "Divide and Conquer",
        "label": "O(n log n)",
        "reasoning": "Splits array into two halves recursively (log n levels) with O(n) linear merge work at each level.",
        "code": """
void merge(int arr[], int l, int m, int r) {
    int i = l;
    int j = m + 1;
    while (i <= m && j <= r) {
        i++;
    }
}

void mergeSort(int arr[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}
"""
    },
    {
        "name": "quick_sort_recursive",
        "family": "Divide and Conquer",
        "label": "O(n log n)",
        "reasoning": "Standard divide-and-conquer partition with two recursive subcalls per level.",
        "code": """
int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            int t = arr[i]; arr[i] = arr[j]; arr[j] = t;
        }
    }
    int t2 = arr[i + 1]; arr[i + 1] = arr[high]; arr[high] = t2;
    return i + 1;
}

void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}
"""
    },
    {
        "name": "loop_with_log_inner",
        "family": "Nested Loops / Mixed",
        "label": "O(n log n)",
        "reasoning": "Outer loop runs n times; inner loop multiplies j by 2 each step running log n times.",
        "code": """
int nLogNLoops(int n) {
    int count = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 1; j < n; j *= 2) {
            count++;
        }
    }
    return count;
}
"""
    },
    {
        "name": "outer_halving_inner_linear",
        "family": "Nested Loops / Mixed",
        "label": "O(n log n)",
        "reasoning": "Outer while loop divides i by 2 (log n steps); inner loop runs linearly n times.",
        "code": """
int logOuterLinearInner(int n) {
    int sum = 0;
    int i = n;
    while (i > 1) {
        for (int j = 0; j < n; j++) {
            sum += j;
        }
        i = i / 2;
    }
    return sum;
}
"""
    },
    {
        "name": "heapify_simulation",
        "family": "Heap / Tree",
        "label": "O(n log n)",
        "reasoning": "Building/extracting a heap involves n steps of tree sinking of depth log n.",
        "code": """
void sink(int arr[], int n, int i) {
    while (2 * i + 1 < n) {
        int left = 2 * i + 1;
        i = left;
    }
}

void heapSortSimulation(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        sink(arr, n, i);
    }
}
"""
    },

    # ==========================
    # 5. O(n^2) - Quadratic Time
    # ==========================
    {
        "name": "bubble_sort",
        "family": "Nested Comparison Sort",
        "label": "O(n^2)",
        "reasoning": "Two nested loops both running up to n iterations with swap comparisons.",
        "code": """
void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
"""
    },
    {
        "name": "selection_sort",
        "family": "Nested Comparison Sort",
        "label": "O(n^2)",
        "reasoning": "Nested loops where inner loop scans remaining n - i elements.",
        "code": """
void selectionSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx])
                minIdx = j;
        }
        int temp = arr[minIdx];
        arr[minIdx] = arr[i];
        arr[i] = temp;
    }
}
"""
    },
    {
        "name": "insertion_sort",
        "family": "Nested Comparison Sort",
        "label": "O(n^2)",
        "reasoning": "Outer loop traverses array while inner while loop shifts elements backward.",
        "code": """
void insertionSort(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}
"""
    },
    {
        "name": "matrix_addition",
        "family": "Matrix Operation",
        "label": "O(n^2)",
        "reasoning": "Two strictly nested loops traversing an n x n matrix.",
        "code": """
void matrixAdd(int A[100][100], int B[100][100], int C[100][100], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            C[i][j] = A[i][j] + B[i][j];
        }
    }
}
"""
    },
    {
        "name": "all_pairs_comparison",
        "family": "Pairwise Comparison",
        "label": "O(n^2)",
        "reasoning": "Checks all pairs (i, j) for duplicates with nested loops.",
        "code": """
int hasDuplicates(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (arr[i] == arr[j])
                return 1;
        }
    }
    return 0;
}
"""
    },
    {
        "name": "nested_while_quad",
        "family": "Nested Loops",
        "label": "O(n^2)",
        "reasoning": "Two nested while loops with linear increments.",
        "code": """
int quadraticCounter(int n) {
    int count = 0;
    int i = 0;
    while (i < n) {
        int j = 0;
        while (j < n) {
            count++;
            j++;
        }
        i++;
    }
    return count;
}
"""
    },

    # ==========================
    # 6. O(2^n) - Exponential Time
    # ==========================
    {
        "name": "recursive_fibonacci",
        "family": "Branching Recursion",
        "label": "O(2^n)",
        "reasoning": "Classic binary recursive branching: fib(n) = fib(n-1) + fib(n-2) yielding ~2^n nodes in call tree.",
        "code": """
int fibonacci(int n) {
    if (n <= 1)
        return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}
"""
    },
    {
        "name": "tower_of_hanoi",
        "family": "Branching Recursion",
        "label": "O(2^n)",
        "reasoning": "Solves Hanoi by moving n-1 disks twice recursively: T(n) = 2T(n-1) + 1 = 2^n - 1 moves.",
        "code": """
void towerOfHanoi(int n, int from_rod, int to_rod, int aux_rod) {
    if (n == 1) {
        return;
    }
    towerOfHanoi(n - 1, from_rod, aux_rod, to_rod);
    towerOfHanoi(n - 1, aux_rod, to_rod, from_rod);
}
"""
    },
    {
        "name": "knapsack_recursive_bruteforce",
        "family": "Branching Recursion",
        "label": "O(2^n)",
        "reasoning": "0/1 Knapsack brute force considers include and exclude choices recursively (2 branches per item).",
        "code": """
int knapSack(int W, int wt[], int val[], int n) {
    if (n == 0 || W == 0)
        return 0;
    if (wt[n - 1] > W)
        return knapSack(W, wt, val, n - 1);
    int inc = val[n - 1] + knapSack(W - wt[n - 1], wt, val, n - 1);
    int exc = knapSack(W, wt, val, n - 1);
    if (inc > exc)
        return inc;
    return exc;
}
"""
    },
    {
        "name": "subset_sum_recursive",
        "family": "Branching Recursion",
        "label": "O(2^n)",
        "reasoning": "Explores all 2^n possible subsets through two recursive branches (include or exclude current element).",
        "code": """
int isSubsetSum(int set[], int n, int sum) {
    if (sum == 0)
        return 1;
    if (n == 0)
        return 0;
    if (set[n - 1] > sum)
        return isSubsetSum(set, n - 1, sum);
    return isSubsetSum(set, n - 1, sum) || isSubsetSum(set, n - 1, sum - set[n - 1]);
}
"""
    },
    {
        "name": "binary_tree_paths_exponential",
        "family": "Branching Recursion",
        "label": "O(2^n)",
        "reasoning": "Simulated complete binary tree traversal with 2 independent recursive branches for left and right children.",
        "code": """
int countTreePaths(int depth) {
    if (depth <= 0)
        return 1;
    int leftPaths = countTreePaths(depth - 1);
    int rightPaths = countTreePaths(depth - 1);
    return leftPaths + rightPaths;
}
"""
    },

    # ==========================
    # 7. O(n!) - Factorial Time
    # ==========================
    {
        "name": "string_permutations",
        "family": "Backtracking / Permutation",
        "label": "O(n!)",
        "reasoning": "Generates all n! permutations using a recursive call inside an n-iteration loop.",
        "code": """
void swapChars(int a[], int i, int j) {
    int temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}

void permute(int a[], int l, int r) {
    if (l == r) {
        return;
    }
    for (int i = l; i <= r; i++) {
        swapChars(a, l, i);
        permute(a, l + 1, r);
        swapChars(a, l, i);
    }
}
"""
    },
    {
        "name": "traveling_salesperson_bruteforce",
        "family": "Backtracking / Permutation",
        "label": "O(n!)",
        "reasoning": "Tries all (n-1)! Hamiltonian tours by visiting every unvisited city recursively inside a loop.",
        "code": """
int tspHelper(int graph[10][10], int visited[10], int currPos, int n, int count, int cost) {
    if (count == n) {
        return cost;
    }
    int ans = 999999;
    for (int i = 0; i < n; i++) {
        if (visited[i] == 0) {
            visited[i] = 1;
            int newCost = tspHelper(graph, visited, i, n, count + 1, cost + graph[currPos][i]);
            if (newCost < ans)
                ans = newCost;
            visited[i] = 0;
        }
    }
    return ans;
}
"""
    },
    {
        "name": "n_queens_backtracking",
        "family": "Backtracking / Permutation",
        "label": "O(n!)",
        "reasoning": "Explores column placements for each row with recursive branch inside an n-sized loop, bounded by O(n!).",
        "code": """
int isSafe(int board[10][10], int row, int col, int n) {
    return 1;
}

int solveNQUtil(int board[10][10], int col, int n) {
    if (col >= n)
        return 1;
    for (int i = 0; i < n; i++) {
        if (isSafe(board, i, col, n)) {
            board[i][col] = 1;
            if (solveNQUtil(board, col + 1, n) == 1)
                return 1;
            board[i][col] = 0;
        }
    }
    return 0;
}
"""
    },
    {
        "name": "bogosort_simulation",
        "family": "Permutation / Random",
        "label": "O(n!)",
        "reasoning": "Permutes an array until sorted; generating all random permutations has average O(n!) complexity.",
        "code": """
int isSorted(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1])
            return 0;
    }
    return 1;
}

void bogoPermute(int arr[], int l, int r) {
    if (l == r) {
        if (isSorted(arr, r + 1))
            return;
    }
    for (int i = l; i <= r; i++) {
        int t = arr[l]; arr[l] = arr[i]; arr[i] = t;
        bogoPermute(arr, l + 1, r);
        t = arr[l]; arr[l] = arr[i]; arr[i] = t;
    }
}
"""
    }
]


def build_dataset() -> pd.DataFrame:
    """
    Parses all programs in the dataset, extracts AST features, and returns a consolidated DataFrame.
    """
    rows = []
    print(f"Building dataset from {len(PROGRAM_DATA)} curated C programs...")
    for idx, item in enumerate(PROGRAM_DATA):
        code = item["code"]
        feats, err = extract_features_from_code(code)
        if err:
            raise RuntimeError(f"Failed to parse program #{idx} ({item['name']}): {err}")
        
        row = {
            "name": item["name"],
            "family": item["family"],
            "label": item["label"],
            "reasoning": item["reasoning"],
            "code": item["code"].strip()
        }
        row.update(feats)
        rows.append(row)
        
    df = pd.DataFrame(rows)
    return df


def save_dataset(csv_path: str = "data/programs.csv") -> pd.DataFrame:
    """Builds and saves the dataset to CSV."""
    os.makedirs(os.path.dirname(csv_path), exist_ok=True)
    df = build_dataset()
    df.to_csv(csv_path, index=False)
    print(f"Successfully saved {len(df)} records to {csv_path}")
    print(f"Class distribution:\n{df['label'].value_counts()}")
    return df


if __name__ == "__main__":
    csv_file = os.path.join(os.path.dirname(__file__), "data", "programs.csv")
    save_dataset(csv_file)
