"""
Prediction Pipeline for CodeComplexity AI.
Loads the genuine trained model and runs end-to-end inference on C source code.
Never fabricates predictions or falls back to synthetic hardcoding.
"""

import os
import joblib
import pandas as pd
from typing import Dict, Any, Tuple, Optional
from feature_extractor import extract_features_from_code, FEATURE_NAMES

MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "complexity_model.joblib")


def load_complexity_model(model_path: str = MODEL_PATH):
    """
    Loads the trained model bundle containing the classifier, model name, and classes.
    Raises FileNotFoundError if model has not been trained yet.
    """
    if not os.path.exists(model_path):
        raise FileNotFoundError(
            f"Trained model not found at '{model_path}'. "
            "Please run train_model.py first to train and save the model."
        )
    bundle = joblib.load(model_path)
    return bundle


def predict_complexity(code: str, model_path: str = MODEL_PATH) -> Dict[str, Any]:
    """
    End-to-end prediction function:
    1. Parses C code and extracts AST features.
    2. Loads trained ML model.
    3. Predicts Big-O time complexity class with class probabilities.
    
    Returns a dictionary with:
    - success (bool)
    - predicted_class (str or None)
    - probabilities (dict or None)
    - features (dict or None)
    - model_name (str or None)
    - error (str or None)
    """
    # Step 1: Extract features
    features, err = extract_features_from_code(code)
    if err:
        return {
            "success": False,
            "predicted_class": None,
            "probabilities": None,
            "features": None,
            "model_name": None,
            "error": err
        }
        
    # Step 2: Load Model
    try:
        bundle = load_complexity_model(model_path)
    except Exception as e:
        return {
            "success": False,
            "predicted_class": None,
            "probabilities": None,
            "features": features,
            "model_name": None,
            "error": f"Model Loading Failed: {str(e)}"
        }
        
    model = bundle["model"]
    model_name = bundle.get("model_name", "Trained Classifier")
    feature_names = bundle.get("feature_names", FEATURE_NAMES)
    
    # Step 3: Format features into 2D array matching training order
    feat_vector = [[features[f] for f in feature_names]]
    
    try:
        prediction = model.predict(feat_vector)[0]
        
        # Probabilities if available
        probabilities = {}
        if hasattr(model, "predict_proba"):
            probs = model.predict_proba(feat_vector)[0]
            for cls_name, prob in zip(model.classes_, probs):
                probabilities[cls_name] = round(float(prob), 4)
                
        return {
            "success": True,
            "predicted_class": prediction,
            "probabilities": probabilities,
            "features": features,
            "model_name": model_name,
            "error": None
        }
    except Exception as e:
        return {
            "success": False,
            "predicted_class": None,
            "probabilities": None,
            "features": features,
            "model_name": model_name,
            "error": f"Prediction Execution Error: {str(e)}"
        }


if __name__ == "__main__":
    sample_code = """
    int search(int arr[], int n, int x) {
        for (int i = 0; i < n; i++) {
            if (arr[i] == x)
                return i;
        }
        return -1;
    }
    """
    res = predict_complexity(sample_code)
    print("Prediction result:", res)
