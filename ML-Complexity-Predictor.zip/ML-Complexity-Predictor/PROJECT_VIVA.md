# PROJECT_VIVA.md: Comprehensive Viva & Technical Interview Guide 🎓

## 1. Project Introduction

**CodeComplexity AI** is a static code analysis and machine learning system that predicts the asymptotic time complexity ($O(1)$, $O(\log n)$, $O(n)$, $O(n \log n)$, $O(n^2)$, $O(2^n)$, $O(n!)$) of C source code. Instead of running arbitrary or potentially unsafe code, it leverages **Compiler Design principles** (Lexical Analysis, Syntactic Parsing, and Abstract Syntax Tree generation via `pycparser`) to extract 17 structural features, which are then classified by trained Machine Learning models (**Decision Tree** and **Random Forest**).

---

## 2. Compiler Design Concepts Used

### A. The Front-End Compiler Phases
1. **Lexical Analysis (Lexing / Scanning)**: Converts the raw character stream of C source code into meaningful tokens (keywords like `for`, `while`, identifiers, operators, separators).
2. **Syntactic Analysis (Parsing)**: Analyzes the token stream against the formal Context-Free Grammar (CFG) of ANSI C using a parser (LALR(1) parser engine in `pycparser`).
3. **Abstract Syntax Tree (AST)**: A hierarchical tree data structure that represents the abstract syntactic structure of source code, omitting superfluous syntax details (like semicolons, parentheses) while preserving operative structure.
4. **AST Visitor Pattern**: Traversal mechanism where a visitor object (`c_ast.NodeVisitor`) recursively visits each node in the AST (`visit_For`, `visit_While`, `visit_FuncDef`, `visit_FuncCall`) to extract semantic metrics.

### B. Why Static AST Analysis Instead of Dynamic Profiling?
- **Safety**: Does not execute potentially untrusted code or trigger infinite loops (Halting Problem).
- **Environment Agnostic**: Big-O complexity measures asymptotic growth rate with respect to input size $n$, not CPU clock time, hardware cache misses, or OS scheduling noise.
- **Fast**: Parsing takes milliseconds without needing compile-and-run toolchains.

---

## 3. Feature Extraction Methodology

The system extracts a 17-dimensional feature vector:
1. `num_for_loops`: Count of `for` loop constructs.
2. `num_while_loops`: Count of `while` loop constructs.
3. `num_do_while_loops`: Count of `do-while` loops.
4. `total_loops`: Cumulative count of all iterative loops.
5. `max_loop_depth`: Maximum depth of nested loops (e.g. single loop = 1, double nested = 2).
6. `num_if_statements`: Count of conditional branch statements.
7. `num_switch_cases`: Count of switch-case branching constructs.
8. `max_condition_depth`: Depth of nested conditional branching.
9. `num_functions`: Distinct functions defined in the translation unit.
10. `total_function_calls`: Overall invocation count of functions.
11. `has_recursion`: Binary indicator ($1$ or $0$) indicating if any function invokes itself.
12. `num_recursive_calls`: Frequency of recursive self-calls (crucial for distinguishing single recursion $O(n)$ from binary branching recursion $O(2^n)$ or permutation loops $O(n!)$).
13. `halving_doubling_ops`: Detected binary operations like `n /= 2`, `n >>= 1`, `(l+r)/2`, or `j *= 2` indicative of logarithmic divisions.
14. `linear_step_ops`: Incremental operations like `i++`, `i--`, `i += 1`.
15. `num_assignments`: Total scalar assignments.
16. `num_binary_ops`: Binary arithmetic/logic operations.
17. `num_returns`: Return statement count.

---

## 4. Machine Learning Workflow & Model Comparison

### Workflow
1. **Dataset Construction**: Curated 38 representative benchmark programs spanning 7 complexity classes.
2. **Feature Extraction**: All code snippets parsed to ensure 100% syntactically valid AST extraction.
3. **Stratified Train-Test Split**: 75% training, 25% holdout test set with class stratification to ensure equal representation.
4. **4-Fold Stratified Cross-Validation**: Provides unbiased generalization metrics across all 38 instances.
5. **Model Serialization**: Saving model weights, labels, and feature names into `models/complexity_model.joblib`.

### Decision Tree vs. Random Forest
| Feature | Decision Tree | Random Forest |
|---|---|---|
| **Structure** | Single hierarchical tree with rule-based splits | Ensemble of $M$ randomized decision trees |
| **Interpretability** | High: Direct `if-else` feature thresholds | Lower: Aggregated voting across multiple trees |
| **Variance / Overfitting** | Prone to overfitting on small datasets | Resilient to overfitting due to bagging / bagging variance reduction |
| **Performance in our Dataset** | 68.4% CV Accuracy | 65.8% CV Accuracy |

---

## 5. Evaluation Metrics Explained Simply

- **Accuracy**: Percentage of correct predictions out of all predictions:
  $$\text{Accuracy} = \frac{\text{Correct Predictions}}{\text{Total Predictions}}$$
- **Precision**: Out of all programs the model predicted as $O(n^2)$, what fraction was actually $O(n^2)$? Measures false positives.
- **Recall**: Out of all actual $O(n^2)$ programs in the dataset, what fraction did the model correctly identify? Measures false negatives.
- **F1-Score**: Harmonic mean of Precision and Recall. Essential when evaluating balanced performance across multiple classes.
- **Confusion Matrix**: A $7 \times 7$ grid showing true labels on rows and predicted labels on columns, identifying where misclassifications occur (e.g. confusing $O(\log n)$ with $O(1)$).

---

## 6. Top 18 Viva Questions with Beginner-Friendly Answers

### Q1: What is the main objective of this project?
> **Answer**: The objective is to analyze C source code without executing it, extract structural features using an Abstract Syntax Tree (AST), and predict its Big-O algorithmic time-complexity class ($O(1)$ to $O(n!)$) using machine learning.

### Q2: Why use pycparser instead of writing regular expressions (regex)?
> **Answer**: Regular expressions cannot handle arbitrary nested languages like C due to Chomsky hierarchy limits (C grammar requires context-free parsing with matching braces and scoping). `pycparser` performs genuine lexical tokenization and syntactic parsing into an AST.

### Q3: What is an Abstract Syntax Tree (AST)?
> **Answer**: An AST is a tree representation of the syntactic structure of source code. In our project, node types like `For`, `While`, `FuncDef`, and `BinaryOp` represent program constructs in a structured hierarchy.

### Q4: How does your code detect recursive functions?
> **Answer**: Our AST visitor records all function definitions and all function calls made within each function. If a function calls its own name, we flag `has_recursion = 1` and record the count of self-calls.

### Q5: How do you differentiate $O(n)$ linear recursion from $O(2^n)$ exponential recursion?
> **Answer**: A linear recursive function (like recursive countdown) has a single recursive call ($T(n) = T(n-1) + O(1) = O(n)$). Branching recursion (like Fibonacci: `fib(n-1) + fib(n-2)`) has 2 recursive calls per invocation, creating an exponential binary tree with $\sim 2^n$ nodes. Our feature `num_recursive_calls` captures this distinction.

### Q6: How do you detect $O(\log n)$ or logarithmic complexity?
> **Answer**: Algorithms with logarithmic complexity (like Binary Search or Euclidean GCD) repeatedly halve the search space or problem size. Our feature extractor identifies assignments and operations that divide by 2 (`n /= 2`, `(l+r)/2`), shift bits (`>>= 1`), or multiply step variables (`j *= 2`).

### Q7: Can this machine learning model replace mathematical complexity proofs?
> **Answer**: No. This model is an educational predictive tool. Proving time complexity mathematically requires asymptotic analysis. Because static analysis cannot solve the Halting Problem, empirical ML provides heuristic estimations rather than mathematical proofs.

### Q8: What is the Halting Problem, and why does it affect static complexity analysis?
> **Answer**: Formulated by Alan Turing in 1936, the Halting Problem proves that no general algorithm can determine whether an arbitrary computer program will finish running or run forever. Since complexity analysis requires knowing termination and loop bounds, perfect static complexity analysis for all arbitrary programs is theoretically impossible.

### Q9: Why did you not execute the user's C code dynamically with timers?
> **Answer**: Dynamic execution can trigger infinite loops, security vulnerabilities, and memory leaks. Furthermore, measuring elapsed wall-clock time depends on CPU load, cache hits, and RAM speed rather than pure mathematical Big-O asymptotic growth.

### Q10: What target complexity classes does your application support?
> **Answer**: 7 classes:
> 1. $O(1)$ (Constant)
> 2. $O(\log n)$ (Logarithmic)
> 3. $O(n)$ (Linear)
> 4. $O(n \log n)$ (Linearithmic)
> 5. $O(n^2)$ (Quadratic)
> 6. $O(2^n)$ (Exponential)
> 7. $O(n!)$ (Factorial)

### Q11: How did you avoid data leakage between training and evaluation?
> **Answer**: We performed stratified splitting to keep holdout test samples distinct from training samples, and evaluated models using 4-Fold Stratified Cross-Validation on the full dataset so test folds remained unseen during training.

### Q12: Why did Decision Tree perform slightly better than Random Forest on this dataset?
> **Answer**: Our educational dataset contains 38 curated benchmark examples where structural features (like `max_loop_depth = 2` for $O(n^2)$ or `num_recursive_calls = 2` for $O(2^n)$) provide sharp, deterministic split thresholds. On small datasets, an ensemble of 50 randomized trees with bootstrap sampling can sometimes exhibit slightly higher variance than a single pruned decision tree.

### Q13: What does the Confusion Matrix show?
> **Answer**: The confusion matrix plots actual versus predicted classes. High values along the diagonal indicate correct classifications, while off-diagonal values pinpoint where the model confused one class for another.

### Q14: What happens if the user submits invalid C code with syntax errors?
> **Answer**: `pycparser` raises a parse error. Our application catches this exception and displays a friendly error notification explaining the syntax issue, rather than crashing or guessing.

### Q15: How does your code sanitize C code before passing it to pycparser?
> **Answer**: `pycparser` is a pure C parser without a built-in preprocessor. Our `sanitize_c_code` function strips `#include` and `#define` directives and injects standard typedef declarations (`bool`, `size_t`) so the parser recognizes standard keywords.

### Q16: How do you identify $O(n!)$ factorial complexity?
> **Answer**: Permutation and backtracking algorithms (e.g. generating permutations or N-Queens) typically feature a recursive call placed inside a loop iterating from $0$ to $n$. The combination of loop presence, function calls, and recursion indicates factorial/backtracking behavior.

### Q17: What are the main limitations of your dataset?
> **Answer**: The dataset has 38 curated academic programs. While they represent standard algorithmic paradigms, real-world code often has multiple helper functions, complex pointers, or library abstractions that can dilute these heuristics.

### Q18: What is Gini Importance in Decision Trees?
> **Answer**: Gini Importance (or Mean Decrease Impurity) measures how much a specific feature reduces the Gini impurity across the tree's split nodes. In our trained model, `num_recursive_calls`, `max_loop_depth`, and `halving_doubling_ops` had the highest Gini importance.

---

## 7. Resume Project Description

**CodeComplexity AI — ML-Based Program Complexity Predictor**  
*Python, pycparser (AST), Scikit-Learn, Streamlit, Pandas, Pytest*
- Built a static analysis tool that parses ANSI C source code into an Abstract Syntax Tree (AST) using `pycparser` and extracts 17 compiler structural features (nesting depth, recursion counts, halving/doubling patterns).
- Trained Decision Tree and Random Forest classifiers across 7 Big-O complexity classes ($O(1)$ to $O(n!)$) achieving 68.4% 4-fold cross-validation accuracy on a curated educational benchmark dataset without data leakage.
- Developed an interactive Streamlit web dashboard featuring real-time C syntax analysis, AST feature tables, class probability distributions, and genuine model evaluation metrics.
- Implemented an automated test suite with 15 unit tests covering AST traversal, preprocessor sanitization, edge cases, and end-to-end inference.
