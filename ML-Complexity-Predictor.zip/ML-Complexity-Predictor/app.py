"""
CodeComplexity AI — ML-Based Program Complexity Predictor
A polished, modern developer tool for analyzing C code algorithmic time-complexity using AST traversal.
Theme: Clean Navy, Slate Blue, White, and Subtle Lavender accents. Zero emojis.
"""

import os
import json
import textwrap
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from PIL import Image

from predict import predict_complexity, load_complexity_model
from feature_extractor import FEATURE_NAMES

# Page configuration
st.set_page_config(
    page_title="CodeComplexity AI — Program Complexity Predictor",
    page_icon=None,
    layout="wide",
    initial_sidebar_state="collapsed"
)

def render_html(content: str):
    """
    Renders pure HTML cleanly without markdown parsing interference,
    preventing indented lines from being misconstrued as code blocks.
    """
    clean = textwrap.dedent(content).strip()
    if hasattr(st, "html"):
        st.html(clean)
    else:
        st.markdown(clean, unsafe_allow_html=True)

# Comprehensive Custom CSS for Developer-Tool Aesthetic
CUSTOM_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');

    /* Global resets and typography */
    html, body, [class*="css"] {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
    }

    .stApp {
        background-color: #F7F9FC !important;
        color: #17233F !important;
    }

    /* Container constraints */
    .block-container {
        padding-top: 1.8rem !important;
        padding-bottom: 3rem !important;
        max-width: 1240px !important;
    }

    /* Hero Banner Header */
    .hero-banner {
        position: relative;
        overflow: hidden;
        background: linear-gradient(135deg, #0e1e3e 0%, #152c5b 45%, #1c3875 80%, #234394 100%);
        padding: 38px 48px;
        border-radius: 16px;
        color: #FFFFFF;
        box-shadow: 0 10px 30px rgba(14, 30, 62, 0.25);
        margin-bottom: 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border: 1px solid rgba(255, 255, 255, 0.08);
    }

    .hero-banner-content {
        position: relative;
        z-index: 2;
        max-width: 65%;
    }

    .hero-title {
        font-size: 34px;
        font-weight: 800;
        letter-spacing: -0.025em;
        line-height: 1.15;
        margin: 0 0 10px 0;
        color: #FFFFFF;
    }

    .hero-title-accent {
        color: #4F7DF9;
    }

    .hero-subtitle {
        color: #94A3B8;
        font-size: 14.5px;
        line-height: 1.55;
        margin: 0;
        font-weight: 400;
        max-width: 580px;
    }

    .hero-aside {
        position: relative;
        z-index: 2;
        text-align: right;
        max-width: 30%;
    }

    .hero-tagline {
        font-size: 16px;
        font-weight: 600;
        color: #FFFFFF;
        letter-spacing: 0.01em;
        margin-bottom: 6px;
    }

    .hero-tagline .accent {
        color: #4F7DF9;
    }

    .hero-tagline .dot {
        opacity: 0.35;
        margin: 0 4px;
    }

    .hero-tagline-sub {
        font-size: 13px;
        color: #94A3B8;
        line-height: 1.45;
    }

    /* Abstract background curves */
    .hero-waves {
        position: absolute;
        right: 0;
        bottom: 0;
        width: 65%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
        opacity: 0.22;
    }

    /* Navigation Tabs */
    div[data-baseweb="tab-list"] {
        gap: 8px !important;
        background-color: transparent !important;
        border-bottom: none !important;
        padding: 4px 0 14px 0 !important;
        display: flex !important;
        flex-wrap: wrap !important;
    }

    button[data-baseweb="tab"] {
        background-color: transparent !important;
        border: 1px solid transparent !important;
        border-radius: 8px !important;
        padding: 9px 18px !important;
        color: #475569 !important;
        font-weight: 500 !important;
        font-size: 13.5px !important;
        transition: all 0.2s ease !important;
        display: inline-flex !important;
        align-items: center !important;
        gap: 8px !important;
    }

    button[data-baseweb="tab"][aria-selected="true"] {
        background-color: #3B66F5 !important;
        color: #FFFFFF !important;
        border-color: #3B66F5 !important;
        box-shadow: 0 2px 10px rgba(59, 102, 245, 0.25) !important;
    }

    button[data-baseweb="tab"]:hover {
        background-color: #EEF2F6 !important;
        color: #17233F !important;
    }

    div[data-baseweb="tab-highlight"],
    div[data-baseweb="tab-border"] {
        display: none !important;
    }

    /* Icon SVGs via CSS Masks on Tab buttons */
    button[data-baseweb="tab"]:nth-child(1)::before {
        content: "";
        display: inline-block;
        width: 15px;
        height: 15px;
        background-color: currentColor;
        mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='16 18 22 12 16 6'/%3E%3Cpolyline points='8 6 2 12 8 18'/%3E%3C/svg%3E");
        -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='16 18 22 12 16 6'/%3E%3Cpolyline points='8 6 2 12 8 18'/%3E%3C/svg%3E");
        mask-repeat: no-repeat;
        -webkit-mask-repeat: no-repeat;
        mask-size: contain;
        -webkit-mask-size: contain;
    }

    button[data-baseweb="tab"]:nth-child(2)::before {
        content: "";
        display: inline-block;
        width: 15px;
        height: 15px;
        background-color: currentColor;
        mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M18 20V10M12 20V4M6 20v-6'/%3E%3C/svg%3E");
        -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M18 20V10M12 20V4M6 20v-6'/%3E%3C/svg%3E");
        mask-repeat: no-repeat;
        -webkit-mask-repeat: no-repeat;
        mask-size: contain;
        -webkit-mask-size: contain;
    }

    button[data-baseweb="tab"]:nth-child(3)::before {
        content: "";
        display: inline-block;
        width: 15px;
        height: 15px;
        background-color: currentColor;
        mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3Cpath d='M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z'/%3E%3C/svg%3E");
        -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='3'/%3E%3Cpath d='M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z'/%3E%3C/svg%3E");
        mask-repeat: no-repeat;
        -webkit-mask-repeat: no-repeat;
        mask-size: contain;
        -webkit-mask-size: contain;
    }

    button[data-baseweb="tab"]:nth-child(4)::before {
        content: "";
        display: inline-block;
        width: 15px;
        height: 15px;
        background-color: currentColor;
        mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cellipse cx='12' cy='5' rx='9' ry='3'/%3E%3Cpath d='M21 12c0 1.66-4 3-9 3s-9-1.34-9-3'/%3E%3Cpath d='M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5'/%3E%3C/svg%3E");
        -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cellipse cx='12' cy='5' rx='9' ry='3'/%3E%3Cpath d='M21 12c0 1.66-4 3-9 3s-9-1.34-9-3'/%3E%3Cpath d='M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5'/%3E%3C/svg%3E");
        mask-repeat: no-repeat;
        -webkit-mask-repeat: no-repeat;
        mask-size: contain;
        -webkit-mask-size: contain;
    }

    button[data-baseweb="tab"]:nth-child(5)::before {
        content: "";
        display: inline-block;
        width: 15px;
        height: 15px;
        background-color: currentColor;
        mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'/%3E%3Cline x1='12' y1='9' x2='12' y2='13'/%3E%3Cline x1='12' y1='17' x2='12.01' y2='17'/%3E%3C/svg%3E");
        -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'/%3E%3Cline x1='12' y1='9' x2='12' y2='13'/%3E%3Cline x1='12' y1='17' x2='12.01' y2='17'/%3E%3C/svg%3E");
        mask-repeat: no-repeat;
        -webkit-mask-repeat: no-repeat;
        mask-size: contain;
        -webkit-mask-size: contain;
    }

    /* Main Tab Panel White Card Enclosure */
    div[data-baseweb="tab-panel"] {
        background-color: #FFFFFF !important;
        border: 1px solid #E2E8F5 !important;
        border-radius: 16px !important;
        padding: 34px 38px !important;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.025) !important;
        margin-top: 2px !important;
    }

    /* Inputs and Code Editor Styling */
    .stSelectbox div[data-baseweb="select"] > div {
        background-color: #FAFBFD !important;
        border: 1px solid #E2E8F5 !important;
        border-radius: 8px !important;
        font-size: 13.5px !important;
        color: #17233F !important;
        transition: border-color 0.2s ease !important;
    }

    .stSelectbox div[data-baseweb="select"] > div:hover {
        border-color: #CBD5E1 !important;
    }

    .stTextArea textarea {
        font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace !important;
        font-size: 13.5px !important;
        line-height: 1.65 !important;
        background-color: #FAFBFD !important;
        color: #17233F !important;
        border: 1px solid #E2E8F5 !important;
        border-radius: 10px !important;
        padding: 14px 16px !important;
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.02) !important;
        tab-size: 4 !important;
    }

    .stTextArea textarea:focus {
        border-color: #3B66F5 !important;
        box-shadow: 0 0 0 3px rgba(59, 102, 245, 0.12) !important;
        outline: none !important;
    }

    /* Buttons */
    .stButton > button {
        border-radius: 8px !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        padding: 10px 22px !important;
        transition: all 0.2s ease !important;
    }

    .stButton > button[kind="primary"] {
        background-color: #3B66F5 !important;
        color: #FFFFFF !important;
        border: none !important;
        box-shadow: 0 2px 8px rgba(59, 102, 245, 0.25) !important;
    }

    .stButton > button[kind="primary"]:hover {
        background-color: #2B52DC !important;
        box-shadow: 0 4px 14px rgba(59, 102, 245, 0.35) !important;
        transform: translateY(-1px) !important;
    }

    .stButton > button[kind="secondary"] {
        background-color: #F1F5F9 !important;
        color: #475569 !important;
        border: 1px solid #E2E8F5 !important;
        box-shadow: none !important;
    }

    .stButton > button[kind="secondary"]:hover {
        background-color: #E2E8F0 !important;
        color: #1E293B !important;
    }

    /* Right Sidebar Panel: How It Works */
    .sidebar-panel {
        background-color: #F1F5FD;
        border: 1px solid #E2E8F5;
        border-radius: 14px;
        padding: 24px 20px;
    }

    .sidebar-title {
        font-size: 15.5px;
        font-weight: 700;
        color: #17233F;
        margin: 0 0 18px 0;
        letter-spacing: -0.01em;
    }

    .step-item {
        display: flex;
        gap: 12px;
        margin-bottom: 16px;
        align-items: flex-start;
    }

    .step-circle {
        background-color: #DBEAFE;
        color: #2563EB;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: 700;
        flex-shrink: 0;
        margin-top: 1px;
    }

    .step-name {
        font-size: 13.5px;
        font-weight: 700;
        color: #17233F;
        margin-bottom: 2px;
    }

    .step-desc {
        font-size: 12.2px;
        color: #64748B;
        line-height: 1.45;
    }

    .sidebar-divider {
        height: 1px;
        background-color: #E2E8F5;
        margin: 18px 0;
    }

    .classes-title {
        font-size: 13.5px;
        font-weight: 700;
        color: #17233F;
        margin: 0 0 12px 0;
    }

    .class-pills-row {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
    }

    .class-pill {
        background-color: #FFFFFF;
        border: 1px solid #BFDBFE;
        color: #2563EB;
        border-radius: 9999px;
        padding: 3px 10px;
        font-size: 11.5px;
        font-weight: 600;
        font-family: 'JetBrains Mono', monospace;
    }

    /* Result Card Presentation */
    .prediction-header-card {
        background-color: #F8FAFD;
        border: 1px solid #E2E8F5;
        border-radius: 12px;
        padding: 20px 24px;
        margin: 24px 0 18px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .pred-badge-lg {
        display: inline-block;
        font-size: 32px;
        font-weight: 800;
        color: #2563EB;
        background-color: #EFF6FF;
        border: 2px solid #BFDBFE;
        border-radius: 10px;
        padding: 4px 22px;
        font-family: 'JetBrains Mono', monospace;
        letter-spacing: -0.02em;
        margin-top: 6px;
    }

    /* Alert and callout styling without emojis */
    .note-box {
        background-color: #F8FAFC;
        border-left: 4px solid #3B66F5;
        padding: 14px 18px;
        border-radius: 0 8px 8px 0;
        color: #334155;
        font-size: 13px;
        line-height: 1.55;
        margin: 16px 0;
    }

    .warning-box {
        background-color: #FFFDF5;
        border-left: 4px solid #D97706;
        padding: 14px 18px;
        border-radius: 0 8px 8px 0;
        color: #78350F;
        font-size: 13px;
        line-height: 1.55;
        margin: 16px 0;
    }

    /* Metric overview card */
    .stat-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F5;
        border-radius: 10px;
        padding: 18px 20px;
        text-align: left;
    }

    .stat-label {
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #64748B;
        margin-bottom: 4px;
    }

    .stat-value {
        font-size: 24px;
        font-weight: 700;
        color: #17233F;
    }

    /* Structured Pipeline Step Cards */
    .pipeline-card {
        background-color: #FAFBFD;
        border: 1px solid #E2E8F5;
        border-radius: 10px;
        padding: 18px 20px;
        margin-bottom: 14px;
    }

    .pipeline-step-badge {
        display: inline-block;
        background-color: #EEF2FF;
        color: #4563F5;
        font-size: 11px;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 4px;
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }

    .pipeline-title {
        font-size: 15px;
        font-weight: 700;
        color: #17233F;
        margin-bottom: 6px;
    }

    .pipeline-desc {
        font-size: 13px;
        color: #64748B;
        line-height: 1.5;
        margin: 0;
    }
</style>
"""
render_html(CUSTOM_CSS)

# Preset Benchmark Programs
PRESET_PROGRAMS = {
    "Select an example...": "",
    "1. Constant Time: Array Index & Swap — O(1)": """int swapFirstTwo(int arr[], int n) {
    if (n < 2) return 0;
    int temp = arr[0];
    arr[0] = arr[1];
    arr[1] = temp;
    return 1;
}""",
    "2. Logarithmic Time: Binary Search (Iterative) — O(log n)": """int binarySearch(int arr[], int l, int r, int x) {
    while (l <= r) {
        int m = l + (r - l) / 2;
        if (arr[m] == x)
            return m;
        if (arr[m] < x)
            l = m + 1;
        else
            r = m - 1;
    }
    return -1;
}""",
    "3. Linear Time: Array Search & Accumulate — O(n)": """int linearSearchAndSum(int arr[], int n, int target) {
    int total = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i] == target) {
            total += arr[i];
        }
    }
    return total;
}""",
    "4. Linearithmic Time: Merge Sort Simulation — O(n log n)": """void merge(int arr[], int l, int m, int r) {
    int i = l;
    while (i <= m) {
        i++;
    }
}

void mergeSort(int arr[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}""",
    "5. Quadratic Time: Bubble Sort — O(n²)": """void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}""",
    "6. Exponential Time: Recursive Fibonacci — O(2ⁿ)": """int fibonacci(int n) {
    if (n <= 1)
        return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}""",
    "7. Factorial Time: Backtracking Permutations — O(n!)": """void swap(int a[], int i, int j) {
    int temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}

void permute(int a[], int l, int r) {
    if (l == r) {
        return;
    }
    for (int i = l; i <= r; i++) {
        swap(a, l, i);
        permute(a, l + 1, r);
        swap(a, l, i);
    }
}"""
}

# Hero Banner with Abstract Wave Background
HERO_HTML = """
<div class="hero-banner">
    <div class="hero-banner-content">
        <h1 class="hero-title">Code<span class="hero-title-accent">Complexity</span> AI</h1>
        <p class="hero-subtitle">
            Machine Learning-Powered Algorithmic Time-Complexity Predictor for C Programs using Abstract Syntax Tree (AST) Traversal
        </p>
    </div>
    <div class="hero-aside">
        <div class="hero-tagline">
            Write <span class="dot">·</span> <span class="accent">Analyze</span> <span class="dot">·</span> Understand
        </div>
        <div class="hero-tagline-sub">
            Get accurate time complexity predictions for your C programs.
        </div>
    </div>
    <svg class="hero-waves" viewBox="0 0 800 240" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M150 240C300 180 460 90 800 130V240H150Z" fill="url(#wave1)" />
        <path d="M0 240C220 210 490 120 800 70V240H0Z" fill="url(#wave2)" opacity="0.6" />
        <path d="M280 240C480 190 620 90 800 35V240H280Z" fill="url(#wave3)" opacity="0.4" />
        <defs>
            <linearGradient id="wave1" x1="150" y1="130" x2="800" y2="240" gradientUnits="userSpaceOnUse">
                <stop stop-color="#4F7DF9" />
                <stop offset="1" stop-color="#7B9FFF" stop-opacity="0" />
            </linearGradient>
            <linearGradient id="wave2" x1="0" y1="70" x2="800" y2="240" gradientUnits="userSpaceOnUse">
                <stop stop-color="#7B9FFF" />
                <stop offset="1" stop-color="#4F7DF9" stop-opacity="0.15" />
            </linearGradient>
            <linearGradient id="wave3" x1="280" y1="35" x2="800" y2="240" gradientUnits="userSpaceOnUse">
                <stop stop-color="#A5C1FF" />
                <stop offset="1" stop-color="#4F7DF9" stop-opacity="0" />
            </linearGradient>
        </defs>
    </svg>
</div>
"""
render_html(HERO_HTML)

# Main Navigation Tabs (Clean line icons applied via CSS masks)
tab_analyze, tab_pipeline, tab_dataset, tab_limitations = st.tabs([
    "Analyze C Program",
    "Compiler & AST Pipeline",
    "Educational Dataset",
    "Theoretical Limitations"
])

# ==============================================================================
# TAB 1: ANALYZE C PROGRAM (MAIN DASHBOARD)
# ==============================================================================
with tab_analyze:
    col_left, col_right = st.columns([69, 31], gap="large")

    with col_left:
        render_html("""
        <h2 style="font-size: 21px; font-weight: 700; color: #17233F; margin: 0 0 4px 0; letter-spacing: -0.01em;">
            Input C Source Code
        </h2>
        <p style="font-size: 13.5px; color: #64748B; margin: 0 0 20px 0;">
            Paste any standard C function or choose an educational benchmark below:
        </p>
        """)

        # Step 1: Benchmark Selector
        render_html("""
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 7px;">
            <div style="background-color: #EEF2FF; color: #4563F5; width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700;">1</div>
            <span style="font-size: 13.5px; font-weight: 600; color: #17233F;">Choose a benchmark sample (or write custom code below):</span>
        </div>
        """)

        selected_preset = st.selectbox(
            "Choose a benchmark sample",
            list(PRESET_PROGRAMS.keys()),
            label_visibility="collapsed",
            key="preset_select"
        )

        default_code = PRESET_PROGRAMS.get(selected_preset, "")
        if "user_code" not in st.session_state or default_code:
            st.session_state["user_code"] = default_code

        # Step 2: Code Editor
        render_html("""
        <div style="display: flex; align-items: center; gap: 8px; margin-top: 18px; margin-bottom: 7px;">
            <div style="background-color: #EEF2FF; color: #4563F5; width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700;">2</div>
            <span style="font-size: 13.5px; font-weight: 600; color: #17233F;">C Source Code:</span>
        </div>
        """)

        user_code = st.text_area(
            "C Source Code",
            value=st.session_state["user_code"],
            height=250,
            placeholder="int compute(int arr[], int n) {\n    // Write or paste C code here...\n}",
            label_visibility="collapsed",
            key="code_area"
        )

        # Action Buttons
        col_btn1, col_btn2, _ = st.columns([2.3, 1.2, 4.5])
        with col_btn1:
            analyze_clicked = st.button("Predict Complexity →", type="primary", use_container_width=True)
        with col_btn2:
            clear_clicked = st.button("Clear", type="secondary", use_container_width=True)
            if clear_clicked:
                st.session_state["user_code"] = ""
                st.rerun()

    with col_right:
        # Sidebar: How It Works & Supported Classes
        render_html("""
        <div class="sidebar-panel">
            <div class="sidebar-title">How It Works</div>
            <div class="step-item">
                <div class="step-circle">1</div>
                <div>
                    <div class="step-name">Parse Code</div>
                    <div class="step-desc">The C code is parsed and converted into an Abstract Syntax Tree (AST).</div>
                </div>
            </div>
            <div class="step-item">
                <div class="step-circle">2</div>
                <div>
                    <div class="step-name">Analyze Structure</div>
                    <div class="step-desc">The model analyzes the AST structure and control flow patterns.</div>
                </div>
            </div>
            <div class="step-item">
                <div class="step-circle">3</div>
                <div>
                    <div class="step-name">Predict Complexity</div>
                    <div class="step-desc">A machine learning model predicts the time complexity class (e.g., O(n), O(n²), etc.).</div>
                </div>
            </div>
            <div class="sidebar-divider"></div>
            <div class="classes-title">Supported Complexity Classes</div>
            <div class="class-pills-row">
                <span class="class-pill">O(1)</span>
                <span class="class-pill">O(log n)</span>
                <span class="class-pill">O(n)</span>
                <span class="class-pill">O(n log n)</span>
                <span class="class-pill">O(n²)</span>
                <span class="class-pill">O(2ⁿ)</span>
                <span class="class-pill">O(n!)</span>
            </div>
        </div>
        """)

    # Dynamic Analysis Results Display
    if analyze_clicked:
        if not user_code or not user_code.strip():
            st.warning("Please enter or select valid C source code to analyze.")
        else:
            with st.spinner("Parsing C code with pycparser and evaluating AST feature patterns..."):
                result = predict_complexity(user_code)

            if not result["success"]:
                render_html(f"""
                <div class="warning-box">
                    <b>Parsing or Validation Notice</b><br>
                    {result['error']}<br>
                    <span style="font-size: 12px; opacity: 0.9;">Ensure your C code contains valid ANSI C syntax with return types, parameters, and balanced braces.</span>
                </div>
                """)
            else:
                pred_class = result["predicted_class"]
                probs = result["probabilities"]
                feats = result["features"]
                model_name = result["model_name"]

                CLASS_EXPLANATIONS = {
                    "O(1)": "Constant Time — The execution time remains independent of the input size.",
                    "O(log n)": "Logarithmic Time — Problem space is reduced exponentially (e.g., repeatedly divided by 2).",
                    "O(n)": "Linear Time — Execution time scales in direct linear proportion to the input size.",
                    "O(n log n)": "Linearithmic Time — Characteristic of efficient divide-and-conquer partition and merge algorithms.",
                    "O(n^2)": "Quadratic Time — Execution scales with the square of the input, typical of dual-nested loops.",
                    "O(n²)": "Quadratic Time — Execution scales with the square of the input, typical of dual-nested loops.",
                    "O(2^n)": "Exponential Time — Operations double with each additional element, characteristic of branching recursion.",
                    "O(2ⁿ)": "Exponential Time — Operations double with each additional element, characteristic of branching recursion.",
                    "O(n!)": "Factorial Time — Operations scale with full permutations of n, characteristic of exhaustive backtracking."
                }
                expl = CLASS_EXPLANATIONS.get(pred_class, "Empirical machine learning algorithmic complexity prediction.")

                render_html(f"""
                <div class="prediction-header-card">
                    <div>
                        <div style="font-size: 12px; font-weight: 700; color: #64748B; text-transform: uppercase; letter-spacing: 0.05em;">
                            Predicted Algorithmic Complexity Class
                        </div>
                        <div class="pred-badge-lg">{pred_class}</div>
                        <div style="font-size: 13.5px; color: #475569; margin-top: 8px;">{expl}</div>
                    </div>
                    <div style="text-align: right; border-left: 1px solid #E2E8F5; padding-left: 28px;">
                        <div style="font-size: 12px; color: #64748B; font-weight: 600; text-transform: uppercase;">Classifier Engine</div>
                        <div style="font-size: 15px; font-weight: 700; color: #17233F; margin-top: 2px;">{model_name}</div>
                        <div style="font-size: 12px; color: #3B66F5; margin-top: 2px;">pycparser AST Features</div>
                    </div>
                </div>
                """)

                render_html("""
                <div class="note-box" style="margin-top: 16px;">
                    <b>Theoretical Note:</b> This result is an empirical classification based on AST topological indicators, 
                    not a formal mathematical verification. Static analysis cannot evaluate runtime input dependencies or solve 
                    the undecidable Halting Problem.
                </div>
                """)

# ==============================================================================
# TAB 2: COMPILER & AST PIPELINE
# ==============================================================================
with tab_pipeline:
    render_html("""
    <h2 style="font-size: 21px; font-weight: 700; color: #17233F; margin: 0 0 4px 0;">
        Compiler & AST Feature Extraction Pipeline
    </h2>
    <p style="font-size: 13.5px; color: #64748B; margin: 0 0 24px 0;">
        How raw C source code is tokenized, parsed into an Abstract Syntax Tree, and converted into a machine learning feature vector.
    </p>
    """)

    p1, p2 = st.columns(2, gap="medium")
    with p1:
        render_html("""
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Stage 01</span>
            <div class="pipeline-title">Lexical Tokenization & Sanitization</div>
            <p class="pipeline-desc">
                Stripping preprocessor directives (#include, #define) and injecting standard type typedefs 
                (bool, size_t) to isolate pure programmatic logic for ANSI C parsing.
            </p>
        </div>
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Stage 02</span>
            <div class="pipeline-title">AST Generation (pycparser)</div>
            <p class="pipeline-desc">
                LALR(1) parser engine converts tokens into a hierarchical FileAST tree representing statement blocks, 
                expressions, control-flow statements, and declarations without executing code.
            </p>
        </div>
        """)

    with p2:
        render_html("""
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Stage 03</span>
            <div class="pipeline-title">AST Node Traversal & Feature Extraction</div>
            <p class="pipeline-desc">
                A custom c_ast.NodeVisitor walks AST nodes (For, While, FuncDef, FuncCall, BinaryOp) 
                to compute 17 structural indicators: maximum loop nesting depth, recursion call counts, and halving operations.
            </p>
        </div>
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Stage 04</span>
            <div class="pipeline-title">Supervised Machine Learning Classification</div>
            <p class="pipeline-desc">
                The 17-dimensional feature vector is passed to a trained Decision Tree or Random Forest model 
                to determine the most probable Big-O asymptotic complexity class.
            </p>
        </div>
        """)

# ==============================================================================
# TAB 4: EDUCATIONAL DATASET
# ==============================================================================
with tab_dataset:
    render_html("""
    <h2 style="font-size: 21px; font-weight: 700; color: #17233F; margin: 0 0 4px 0;">
        Educational Benchmark Dataset
    </h2>
    <p style="font-size: 13.5px; color: #64748B; margin: 0 0 20px 0;">
        Curated repository of 38 representative C algorithms spanning 7 complexity classes with reviewed asymptotic justifications.
    </p>
    """)

    data_csv = os.path.join(os.path.dirname(__file__), "data", "programs.csv")
    if os.path.exists(data_csv):
        df_display = pd.read_csv(data_csv)

        col_f1, col_f2 = st.columns([1, 2])
        with col_f1:
            families = ["All Families"] + sorted(df_display["family"].unique().tolist())
            selected_family = st.selectbox("Filter by Algorithm Family:", families)

        filtered_df = df_display if selected_family == "All Families" else df_display[df_display["family"] == selected_family]

        st.dataframe(
            filtered_df[["name", "family", "label", "reasoning", "total_loops", "max_loop_depth", "has_recursion"]],
            hide_index=True,
            use_container_width=True
        )
    else:
        st.info("Run dataset_builder.py to generate data/programs.csv.")

# ==============================================================================
# TAB 5: THEORETICAL LIMITATIONS
# ==============================================================================
with tab_limitations:
    render_html("""
    <h2 style="font-size: 21px; font-weight: 700; color: #17233F; margin: 0 0 4px 0;">
        Theoretical & Practical Limitations
    </h2>
    <p style="font-size: 13.5px; color: #64748B; margin: 0 0 20px 0;">
        Fundamental boundaries of static code analysis in computer science and why machine learning serves as a heuristic assistant.
    </p>
    <div class="warning-box">
        <b>Fundamental Computer Science Principle:</b>
        Static time-complexity prediction cannot replace mathematical asymptotic proof. 
        Because the Halting Problem is undecidable, any static heuristic model functions as an educational estimator.
    </div>
    """)

    lim1, lim2 = st.columns(2, gap="medium")
    with lim1:
        render_html("""
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Boundary 01</span>
            <div class="pipeline-title">The Halting Problem & Undecidability (Turing, 1936)</div>
            <p class="pipeline-desc">
                Proving whether an arbitrary program terminates—and consequently how many steps it takes—is mathematically 
                undecidable. Static AST features cannot resolve Collatz-like dynamic loop terminations.
            </p>
        </div>
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Boundary 02</span>
            <div class="pipeline-title">Runtime Input Invariants & Dynamic Bounds</div>
            <p class="pipeline-desc">
                Static analysis inspects syntax topology, but loop counts frequently depend on input values, pointer aliasing, 
                and dynamic state mutations that are invisible prior to execution.
            </p>
        </div>
        """)

    with lim2:
        render_html("""
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Boundary 03</span>
            <div class="pipeline-title">Amortized & Average-Case Bounds</div>
            <p class="pipeline-desc">
                Data structures such as dynamic arrays (vector push_back) or Union-Find with path compression possess O(1) 
                amortized complexity despite rare worst-case nested operations that mislead static counters.
            </p>
        </div>
        <div class="pipeline-card">
            <span class="pipeline-step-badge">Boundary 04</span>
            <div class="pipeline-title">Educational Dataset Distribution Bias</div>
            <p class="pipeline-desc">
                Trained on 38 curated academic algorithms. Complex production code involving multi-file linker symbols, 
                pointer arithmetic, and macro expansions requires formal abstract interpretation.
            </p>
        </div>
        """)

# Footer
render_html("""
<div style="height: 24px;"></div>
<div style="text-align: center; color: #94A3B8; font-size: 12.5px; padding-top: 16px; border-top: 1px solid #E2E8F5;">
    CodeComplexity AI · Built with Python, pycparser, Scikit-Learn & Streamlit · Compiler Design Static Analysis Project
</div>
""")
