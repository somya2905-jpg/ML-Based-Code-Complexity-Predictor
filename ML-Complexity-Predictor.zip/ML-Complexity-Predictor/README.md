# CodeComplexity AI — ML-Based Program Complexity Predictor ⚡

An educational, resume-worthy **Compiler Design & Machine Learning** project that analyzes C source code, parses it into an **Abstract Syntax Tree (AST)** using `pycparser`, extracts structural complexity features, and predicts the program's algorithmic time-complexity class ($O(1)$, $O(\log n)$, $O(n)$, $O(n \log n)$, $O(n^2)$, $O(2^n)$, $O(n!)$) using trained **Decision Tree** and **Random Forest** classifiers.

---

## 🌟 Key Features

- **AST-Driven Static Analysis**: Uses `pycparser` to parse ANSI C source code into a hierarchical `FileAST` node graph—without executing arbitrary user code.
- **17 Compiler Structural Features**: Extracts maximum loop nesting depths, loop varieties (`for`, `while`, `do-while`), branching conditions, function call counts, recursive self-invocation, and halving/doubling loop progression patterns.
- **Genuine Machine Learning**: Trained on a transparent, curated educational dataset of 38 representative C algorithms with cross-validation and holdout testing (no data leakage).
- **Interactive Streamlit Web Dashboard**: Styled in clean navy, blue, white, and subtle purple. Features interactive C code input, preset benchmarks, AST feature tables, class probability charts, and evaluation plots.
- **Theoretical Limitations & Academic Rigor**: Explicitly addresses the Halting Problem, undecidability, and why empirical ML predictions differ from mathematically verified proofs.
- **Comprehensive Automated Testing**: 15 unit tests across feature extraction, AST traversal, invalid syntax handling, schema consistency, and end-to-end model inference.

---

## 🏗️ Architecture & Pipeline

```
┌────────────────────────┐
│ C Source Code Input    │
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│ Preprocessing/Sanitize │  (Strip preprocessor directives, inject types)
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│ pycparser Lexer/Parser │  (Tokenizes code and constructs FileAST)
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│ AST NodeVisitor        │  (Extracts 17 structural/algorithmic features)
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│ Scikit-Learn Model     │  (Decision Tree / Random Forest Classifier)
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│ Complexity Prediction  │  (Prominent Big-O class badge + Class Probabilities)
└────────────────────────┘
```

---

## 💻 Tech Stack

- **Language**: Python 3.12
- **C Parser**: `pycparser`
- **Data & Numerical Processing**: `pandas`, `numpy`
- **Machine Learning**: `scikit-learn`, `joblib`
- **Frontend / UI**: `streamlit`
- **Visualization**: `matplotlib`, `Pillow`
- **Testing**: `pytest`

---

## 📁 Project Directory Structure

```
ML-Complexity-Predictor/
│
├── app.py                     # Streamlit interactive web application
├── feature_extractor.py       # pycparser AST visitor & 17-D feature extraction
├── dataset_builder.py         # Curated benchmark C programs dataset generator
├── train_model.py             # Model training, cross-validation & evaluation script
├── predict.py                 # End-to-end inference & model loading pipeline
├── requirements.txt           # Python dependency requirements
├── pytest.ini                 # Pytest configuration
├── README.md                  # Comprehensive project documentation
├── PROJECT_VIVA.md            # Viva questions, answers, and concepts guide
├── .gitignore                 # Standard Python/IDE ignore list
│
├── data/
│   └── programs.csv           # Curated educational dataset of 38 C algorithms
│
├── models/
│   ├── complexity_model.joblib # Saved trained model bundle
│   ├── metrics.json           # Genuine evaluation metrics
│   ├── confusion_matrix.png   # Generated confusion matrix plot
│   └── feature_importance.png # Generated feature importance plot
│
└── tests/
    ├── test_feature_extractor.py # Tests for AST parsing, loops, recursion & errors
    └── test_prediction.py        # Tests for model loading, schema & inference
```

---

## 🚀 Installation & Execution on Windows

### 1. Prerequisites
Ensure Python 3.10+ is installed on your Windows system. Check via Command Prompt or PowerShell:
```powershell
python --version
pip --version
```

### 2. Navigate to Project Directory
```powershell
cd C:\Users\somya\.gemini\antigravity-ide\scratch\ML-Complexity-Predictor
```

### 3. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 4. (Optional) Rebuild Dataset & Retrain Models
To regenerate the dataset and retrain the models:
```powershell
python dataset_builder.py
python train_model.py
```

### 5. Run Automated Tests
```powershell
pytest -v
```

### 6. Launch the Streamlit Web Application
```powershell
streamlit run app.py
```
Your default web browser will open `http://localhost:8501`.

---

## 📊 Genuine Evaluation Metrics & Dataset Limitations

### Model Evaluation Summary (4-Fold Cross-Validation)

| Metric | Decision Tree (Depth 6) | Random Forest (50 Trees) |
|---|:---:|:---:|
| **Holdout Test Accuracy** | **70.0%** | **70.0%** |
| **Cross-Validation Accuracy** | **68.4%** | **65.8%** |
| **Weighted Precision** | **66.4%** | **60.8%** |
| **Weighted Recall** | **68.4%** | **65.8%** |
| **Weighted F1-Score** | **65.6%** | **62.7%** |

*Note: In our training run, the Decision Tree achieved a 68.4% cross-validation accuracy on our 38 educational samples, effectively utilizing top features like `num_recursive_calls`, `max_loop_depth`, `halving_doubling_ops`, and `total_loops`.*

### Dataset Methodology & Limitations
- **Transparent Synthetic Dataset**: Consists of 38 representative algorithms spanning standard algorithm families: array access, number theory, linear scanning, divide & conquer, nested comparison sorts, branching recursion, and permutation backtracking.
- **Limitations**:
  - The sample size ($N=38$) is an educational benchmark dataset designed to illustrate compiler AST feature extraction.
  - While AST features capture structural hallmarks reliably, no static ML tool can solve the **Halting Problem** or determine dynamic input-dependent loops without execution.

---

## 💡 Example Inputs & Outputs

### Example 1: Binary Search (Iterative)
**C Input:**
```c
int binarySearch(int arr[], int l, int r, int x) {
    while (l <= r) {
        int m = l + (r - l) / 2;
        if (arr[m] == x)
            return m;
        if (arr[m] < x)
            l = m + 1;
        else
            r = m - 1;
    }
    return -1;
}
```
- **Extracted AST Features**: `total_loops=1`, `max_loop_depth=1`, `has_recursion=0`, `halving_doubling_ops=1`
- **Predicted Complexity**: **$O(\log n)$**

### Example 2: Bubble Sort
**C Input:**
```c
void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
```
- **Extracted AST Features**: `total_loops=2`, `max_loop_depth=2`, `has_recursion=0`, `linear_step_ops=1`
- **Predicted Complexity**: **$O(n^2)$**

### Example 3: Recursive Fibonacci
**C Input:**
```c
int fib(int n) {
    if (n <= 1)
        return n;
    return fib(n - 1) + fib(n - 2);
}
```
- **Extracted AST Features**: `total_loops=0`, `has_recursion=1`, `num_recursive_calls=2`
- **Predicted Complexity**: **$O(2^n)$**

---

## 🔮 Future Scope
- **Control Flow Graph (CFG) Analysis**: Integrating LLVM intermediate representation (IR) or basic block transition graphs.
- **Loop Bound Symbolic Reasoning**: Using Satisfiability Modulo Theories (SMT) solvers (e.g. Z3) for algebraic loop bound invariants.
- **Multi-File Project Analysis**: Support for multi-translation-unit C/C++ projects with inter-procedural analysis.
