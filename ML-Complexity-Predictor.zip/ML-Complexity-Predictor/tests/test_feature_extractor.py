"""
Unit tests for Feature Extractor using pytest.
Validates:
- AST parsing and structural counts
- Basic loop feature extraction
- Nested loop detection & depth
- Recursion detection
- Binary halving/doubling patterns
- Error handling on invalid C input
"""

import pytest
from feature_extractor import extract_features_from_code, sanitize_c_code


def test_invalid_c_input():
    """Invalid or syntactically broken C code should return an error."""
    code = "this is definitely not valid C code {"
    feats, err = extract_features_from_code(code)
    assert feats is None
    assert err is not None
    assert "C Parsing Error" in err


def test_empty_input():
    """Empty code should return an informative error."""
    feats, err = extract_features_from_code("")
    assert feats is None
    assert "Empty source code" in err


def test_constant_time_features():
    """O(1) function with no loops or recursion."""
    code = """
    int add(int a, int b) {
        int c = a + b;
        return c;
    }
    """
    feats, err = extract_features_from_code(code)
    assert err is None
    assert feats is not None
    assert feats["total_loops"] == 0
    assert feats["max_loop_depth"] == 0
    assert feats["has_recursion"] == 0
    assert feats["num_functions"] == 1


def test_single_loop_linear():
    """O(n) linear search has single loop depth 1."""
    code = """
    int search(int arr[], int n, int x) {
        for (int i = 0; i < n; i++) {
            if (arr[i] == x)
                return i;
        }
        return -1;
    }
    """
    feats, err = extract_features_from_code(code)
    assert err is None
    assert feats["total_loops"] == 1
    assert feats["num_for_loops"] == 1
    assert feats["max_loop_depth"] == 1
    assert feats["has_recursion"] == 0


def test_nested_loop_depth():
    """Nested loops should report max_loop_depth == 2."""
    code = """
    void printPairs(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int sum = i + j;
            }
        }
    }
    """
    feats, err = extract_features_from_code(code)
    assert err is None
    assert feats["total_loops"] == 2
    assert feats["max_loop_depth"] == 2
    assert feats["has_recursion"] == 0


def test_triple_nested_loop_depth():
    """Triple nested loops should report max_loop_depth == 3."""
    code = """
    void cubic(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    int prod = i * j * k;
                }
            }
        }
    }
    """
    feats, err = extract_features_from_code(code)
    assert err is None
    assert feats["total_loops"] == 3
    assert feats["max_loop_depth"] == 3


def test_recursion_detection():
    """Recursive Fibonacci should detect has_recursion and multiple recursive calls."""
    code = """
    int fib(int n) {
        if (n <= 1)
            return n;
        return fib(n - 1) + fib(n - 2);
    }
    """
    feats, err = extract_features_from_code(code)
    assert err is None
    assert feats["has_recursion"] == 1
    assert feats["num_recursive_calls"] == 2


def test_halving_progression():
    """Binary division loop should detect halving/doubling ops."""
    code = """
    int halve(int n) {
        while (n > 1) {
            n = n / 2;
        }
        return n;
    }
    """
    feats, err = extract_features_from_code(code)
    assert err is None
    assert feats["num_while_loops"] == 1
    assert feats["halving_doubling_ops"] >= 1


def test_sanitize_preprocessor():
    """Sanitizer should cleanly strip #include directives without breaking parsing."""
    code = """
    #include <stdio.h>
    #include <stdlib.h>
    int run() {
        return 42;
    }
    """
    feats, err = extract_features_from_code(code)
    assert err is None
    assert feats["num_functions"] == 1
