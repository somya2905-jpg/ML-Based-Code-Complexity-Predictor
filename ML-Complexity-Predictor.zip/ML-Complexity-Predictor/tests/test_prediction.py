"""
Automated tests for Prediction Pipeline using pytest.
Validates:
- Trained model loading
- Feature schema consistency between training and prediction
- End-to-end inference on valid C code
- Graceful error handling on invalid code or missing model
- Probability distributions structure
"""

import os
import pytest
from predict import predict_complexity, load_complexity_model
from feature_extractor import FEATURE_NAMES


def test_load_trained_model():
    """Verify that the saved model bundle exists and contains necessary components."""
    bundle = load_complexity_model()
    assert "model" in bundle
    assert "model_name" in bundle
    assert "feature_names" in bundle
    assert "classes" in bundle
    assert bundle["feature_names"] == FEATURE_NAMES
    assert len(bundle["classes"]) >= 7


def test_predict_linear_search():
    """Predict complexity for linear search."""
    code = """
    int linearSearch(int arr[], int n, int x) {
        for (int i = 0; i < n; i++) {
            if (arr[i] == x)
                return i;
        }
        return -1;
    }
    """
    res = predict_complexity(code)
    assert res["success"] is True
    assert res["error"] is None
    assert res["predicted_class"] in ["O(n)", "O(log n)", "O(n^2)", "O(1)", "O(n log n)", "O(2^n)", "O(n!)"]
    assert res["features"] is not None
    assert "total_loops" in res["features"]
    assert res["probabilities"] is not None


def test_predict_bubble_sort():
    """Predict complexity for quadratic bubble sort."""
    code = """
    void bubbleSort(int arr[], int n) {
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    """
    res = predict_complexity(code)
    assert res["success"] is True
    assert res["error"] is None
    assert res["features"]["max_loop_depth"] == 2
    assert res["predicted_class"] == "O(n^2)"


def test_predict_fibonacci_exponential():
    """Predict complexity for branching recursive fibonacci."""
    code = """
    int fib(int n) {
        if (n <= 1)
            return n;
        return fib(n - 1) + fib(n - 2);
    }
    """
    res = predict_complexity(code)
    assert res["success"] is True
    assert res["error"] is None
    assert res["features"]["has_recursion"] == 1
    assert res["features"]["num_recursive_calls"] == 2
    assert res["predicted_class"] == "O(2^n)"


def test_predict_invalid_code_handling():
    """Prediction pipeline should gracefully return failure for invalid syntax."""
    res = predict_complexity("void bad_syntax( {")
    assert res["success"] is False
    assert res["predicted_class"] is None
    assert res["error"] is not None
    assert "C Parsing Error" in res["error"]


def test_feature_consistency_with_training():
    """Extracted feature dictionary keys must match FEATURE_NAMES identically."""
    code = "int f() { return 1; }"
    res = predict_complexity(code)
    assert res["success"] is True
    extracted_keys = list(res["features"].keys())
    assert extracted_keys == FEATURE_NAMES
