"""
Feature Extractor for C Code using pycparser AST Traversal.
Extracts structural and algorithmic complexity indicators from C source code.
"""

import re
from typing import Dict, Any, Tuple, Optional
from pycparser import c_parser, c_ast


def sanitize_c_code(code: str) -> str:
    """
    Sanitize C code for pycparser:
    1. Strip preprocessor directives (#include, #define, etc.)
    2. Normalize common typedefs (size_t, bool, etc.)
    3. Ensure clean formatting
    """
    lines = []
    for line in code.splitlines():
        stripped = line.strip()
        # Remove preprocessor directives
        if stripped.startswith("#"):
            continue
        lines.append(line)
    
    clean_code = "\n".join(lines)
    
    # Common typedefs needed if standard libraries aren't parsed
    preamble = """
typedef int bool;
typedef unsigned long long size_t;
typedef long long int64_t;
"""
    return preamble + "\n" + clean_code


class ASTComplexityVisitor(c_ast.NodeVisitor):
    """
    Traverses the pycparser AST and collects compiler/syntactic structural features.
    """
    def __init__(self):
        super().__init__()
        # Loop features
        self.num_for_loops = 0
        self.num_while_loops = 0
        self.num_do_while_loops = 0
        self.current_loop_depth = 0
        self.max_loop_depth = 0
        
        # Conditionals and branches
        self.num_if_statements = 0
        self.num_switch_cases = 0
        self.current_condition_depth = 0
        self.max_condition_depth = 0
        
        # Functions and Calls
        self.functions_defined = set()
        self.function_calls_in_func = {}  # func_name -> list of called func names
        self.current_function = None
        self.total_function_calls = 0
        
        # Statements & operations
        self.num_assignments = 0
        self.num_binary_ops = 0
        self.num_returns = 0
        
        # Loop progression patterns (halving / doubling)
        self.halving_doubling_indicators = 0
        self.linear_step_indicators = 0

    def visit_FuncDef(self, node):
        func_name = node.decl.name
        self.functions_defined.add(func_name)
        prev_func = self.current_function
        self.current_function = func_name
        self.function_calls_in_func[func_name] = []
        
        # Visit children
        self.generic_visit(node)
        
        self.current_function = prev_func

    def visit_FuncCall(self, node):
        self.total_function_calls += 1
        if isinstance(node.name, c_ast.ID):
            called_name = node.name.name
            if self.current_function:
                self.function_calls_in_func[self.current_function].append(called_name)
        self.generic_visit(node)

    def _enter_loop(self):
        self.current_loop_depth += 1
        if self.current_loop_depth > self.max_loop_depth:
            self.max_loop_depth = self.current_loop_depth

    def _exit_loop(self):
        self.current_loop_depth -= 1

    def visit_For(self, node):
        self.num_for_loops += 1
        self._enter_loop()
        
        # Check loop step / progression
        if node.next:
            self._analyze_loop_step(node.next)
            
        self.generic_visit(node)
        self._exit_loop()

    def visit_While(self, node):
        self.num_while_loops += 1
        self._enter_loop()
        self.generic_visit(node)
        self._exit_loop()

    def visit_DoWhile(self, node):
        self.num_do_while_loops += 1
        self._enter_loop()
        self.generic_visit(node)
        self._exit_loop()

    def visit_If(self, node):
        self.num_if_statements += 1
        self.current_condition_depth += 1
        if self.current_condition_depth > self.max_condition_depth:
            self.max_condition_depth = self.current_condition_depth
        self.generic_visit(node)
        self.current_condition_depth -= 1

    def visit_Switch(self, node):
        self.num_switch_cases += 1
        self.generic_visit(node)

    def visit_Assignment(self, node):
        self.num_assignments += 1
        self._analyze_assignment(node)
        self.generic_visit(node)

    def visit_BinaryOp(self, node):
        self.num_binary_ops += 1
        self.generic_visit(node)

    def visit_Return(self, node):
        self.num_returns += 1
        self.generic_visit(node)

    def _analyze_loop_step(self, node):
        """Detect linear steps vs doubling/halving in for-loop step"""
        if isinstance(node, c_ast.UnaryOp) and node.op in ('p++', '++', 'p--', '--'):
            self.linear_step_indicators += 1
        elif isinstance(node, c_ast.Assignment):
            if node.op in ('*=', '/=', '>>=', '<<='):
                self.halving_doubling_indicators += 1
            elif node.op in ('+=', '-='):
                self.linear_step_indicators += 1

    def _analyze_assignment(self, node):
        """Analyze assignments inside loops or functions for division/multiplication steps"""
        if node.op in ('*=', '/=', '>>=', '<<='):
            self.halving_doubling_indicators += 1
        elif isinstance(node.rvalue, c_ast.BinaryOp):
            if node.rvalue.op in ('/', '*', '>>', '<<'):
                self.halving_doubling_indicators += 1


def extract_features_from_ast(ast: c_ast.FileAST, raw_code: str = "") -> Dict[str, Any]:
    """
    Extracts numerical feature vector from AST node and complementary lexical indicators.
    """
    visitor = ASTComplexityVisitor()
    visitor.visit(ast)
    
    total_loops = visitor.num_for_loops + visitor.num_while_loops + visitor.num_do_while_loops
    
    # Analyze recursion:
    # 1. Does any function call itself?
    # 2. How many recursive calls exist?
    has_recursion = 0
    num_recursive_calls = 0
    for func, calls in visitor.function_calls_in_func.items():
        self_calls = [c for c in calls if c == func]
        if len(self_calls) > 0:
            has_recursion = 1
            num_recursive_calls += len(self_calls)
            
    # Halving/doubling in raw code as fallback/booster (e.g., mid = (l+r)/2 or n / 2)
    lexical_halving_count = 0
    if raw_code:
        # Matches patterns like / 2, >> 1, * 2, << 1
        lexical_halving_count = len(re.findall(r'(\/\s*2|\*\s*2|>>\s*1|<<\s*1|\/\=\s*2|\*\=\s*2)', raw_code))
        
    combined_halving_doubling = max(visitor.halving_doubling_indicators, lexical_halving_count)

    features = {
        "num_for_loops": visitor.num_for_loops,
        "num_while_loops": visitor.num_while_loops,
        "num_do_while_loops": visitor.num_do_while_loops,
        "total_loops": total_loops,
        "max_loop_depth": visitor.max_loop_depth,
        "num_if_statements": visitor.num_if_statements,
        "num_switch_cases": visitor.num_switch_cases,
        "max_condition_depth": visitor.max_condition_depth,
        "num_functions": len(visitor.functions_defined),
        "total_function_calls": visitor.total_function_calls,
        "has_recursion": has_recursion,
        "num_recursive_calls": num_recursive_calls,
        "halving_doubling_ops": combined_halving_doubling,
        "linear_step_ops": visitor.linear_step_indicators,
        "num_assignments": visitor.num_assignments,
        "num_binary_ops": visitor.num_binary_ops,
        "num_returns": visitor.num_returns,
    }
    return features


def extract_features_from_code(code: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Parses C code and extracts features.
    Returns:
        (features_dict, error_message)
        If parsing succeeds, error_message is None.
        If parsing fails, features_dict is None and error_message describes the issue.
    """
    if not code or not code.strip():
        return None, "Error: Empty source code provided."

    sanitized = sanitize_c_code(code)
    parser = c_parser.CParser()
    try:
        ast = parser.parse(sanitized, filename='<input>')
        features = extract_features_from_ast(ast, raw_code=code)
        return features, None
    except Exception as e:
        return None, f"C Parsing Error: {str(e)}. Ensure standard C syntax (functions, typed variables, etc.)."


FEATURE_NAMES = [
    "num_for_loops",
    "num_while_loops",
    "num_do_while_loops",
    "total_loops",
    "max_loop_depth",
    "num_if_statements",
    "num_switch_cases",
    "max_condition_depth",
    "num_functions",
    "total_function_calls",
    "has_recursion",
    "num_recursive_calls",
    "halving_doubling_ops",
    "linear_step_ops",
    "num_assignments",
    "num_binary_ops",
    "num_returns"
]
